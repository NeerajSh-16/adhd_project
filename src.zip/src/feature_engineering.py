import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
import scipy.sparse as sp

def get_numeric_features(df):
    """
    Selects all the numeric features we decided to keep.
    Returns a dataframe with only those columns.
    """
    # ASRS Part B — items 7 to 18 (Part A is the target, never a feature)
    asrs_part_b = [f'asrs1_item_{i}' for i in range(7, 19)]

    # BAI — anxiety total + two strongest individual items
    bai_features = ['bai1_total', 'bai1_item_4', 'bai1_item_8']

    # BDI — depression total + item 19 (concentration difficulty)
    bdi_features = ['bdi1_total', 'bdi1_item_19']

    # AAS — academic adjustment items 3, 4, 6
    aas_features = ['aas1_item_3', 'aas1_item_4', 'aas1_item_6']

    # Combine all numeric features into one list
    all_numeric = asrs_part_b + bai_features + bdi_features + aas_features

    print(f"Numeric features selected: {len(all_numeric)}")
    return df[all_numeric]


def get_categorical_features(df):
    """
    Encodes the categorical columns as numbers.
    Label encoding converts text categories to 0, 1, 2 etc.
    """
    cat_cols = {
        'sex': 'sex',
        'diagnosed': 'have_you_ever_been_diagnosed_with_a_mental_illness',
        'on_medication': 'are_you_currently_using_prescribed_psychiatric_medication_for_a_mental_illness_or_symptoms_of_one',
        'prior_mh': 'have_you_ever_experienced_any_mental_health_difficulties_or_symptoms_before_starting_university_e_g_in_primary_or_high_school'
    }

    encoded = pd.DataFrame()
    le = LabelEncoder()

    for short_name, col_name in cat_cols.items():
        encoded[short_name] = le.fit_transform(df[col_name].astype(str))

    print(f"Categorical features encoded: {len(cat_cols)}")
    return encoded


def get_tfidf_features(df, max_features=100):
    """
    Converts the free-text diagnosis column into TF-IDF numeric features.
    max_features=100 means we keep only the 100 most useful words.
    """
    text_col = 'if_you_have_been_diagnosed_formally_or_informally_please_list_the_diagnosis_diagnoses'

    # Clean the text — lowercase everything
    text_data = df[text_col].astype(str).str.lower()

    # Build the TF-IDF matrix
    vectorizer = TfidfVectorizer(
        max_features=max_features,
        ngram_range=(1, 2),   # single words AND two-word phrases e.g. "anxiety disorder"
        min_df=2              # ignore words that appear in only 1 document
    )

    tfidf_matrix = vectorizer.fit_transform(text_data)
    feature_names = vectorizer.get_feature_names_out()

    print(f"TF-IDF features created: {tfidf_matrix.shape[1]} words/phrases")
    return tfidf_matrix, vectorizer


def build_feature_matrix(df):
    """
    Combines numeric + categorical + TF-IDF features into one matrix.
    This is the final input that goes into the model.
    """
    # Get each feature group
    numeric_df   = get_numeric_features(df)
    category_df  = get_categorical_features(df)
    tfidf_matrix, vectorizer = get_tfidf_features(df)

    # Convert numeric and categorical to sparse matrices so we can stack them
    numeric_sparse  = sp.csr_matrix(numeric_df.values)
    category_sparse = sp.csr_matrix(category_df.values)

    # Stack all features side by side into one big matrix
    X = sp.hstack([numeric_sparse, category_sparse, tfidf_matrix])

    print(f"\nFinal feature matrix shape: {X.shape[0]} rows x {X.shape[1]} features")
    return X, vectorizer